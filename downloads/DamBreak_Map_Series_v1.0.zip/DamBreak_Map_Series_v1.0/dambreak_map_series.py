r"""
QGIS Processing tool: Dam Break Map Series (Atlas + PNG)
Toolbox > Scripts > Dam Break Map Tools > Dam Break Map Series (Atlas + PNG)

Install: Processing Toolbox > Python icon > "Add Script to Toolbox..." > select this file.
Requires QGIS 3.28 or newer (tested on 3.44 LTR). No extra Python packages needed.

Makes a downstream map series (e.g. 1:50,000) for ANY styled layer: maximum depth (inundation),
velocity, hazard / vulnerability, arrival time ... You choose the layer, the map heading
("<heading> 01, 02 ...") and the legend title. Sheets are traced along the flood from the dam,
or reused from an earlier run so every theme uses identical sheets.
Dam details (river, basin, DB peak, PAR, date, dam location) come from the Dam Dashboard report
(DamBreak_PAR_Report.xlsx) and can be overridden in the dialog.
Developed by Rushikesh Jadhav   |   Version 1.0 (Nov 2026)   |   Free to use and adapt; please keep this credit.
"""
import os
import re
import zipfile
import datetime
import xml.etree.ElementTree as ET
from collections import deque

import numpy as np
from osgeo import gdal
from qgis.PyQt.QtCore import QVariant, QCoreApplication, Qt
from qgis.core import (Qgis, QgsProcessing, QgsProcessingAlgorithm, QgsProcessingException,
                       QgsProcessingParameterLayout, QgsProcessingParameterLayoutItem,
                       QgsProcessingParameterRasterLayer, QgsProcessingParameterVectorLayer,
                       QgsProcessingParameterMultipleLayers, QgsProcessingParameterMapLayer, QgsRasterLayer, QgsProcessingParameterString,
                       QgsProcessingParameterFile, QgsProcessingParameterPoint,
                       QgsProcessingParameterEnum, QgsProcessingParameterBoolean,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterDefinition, QgsProcessingOutputNumber,
                       QgsProcessingOutputString, QgsLayoutItemRegistry, QgsLayoutItemMap,
                       QgsLayoutItemLabel, QgsLayoutItemLegend, QgsLayoutItemScaleBar, QgsVectorLayer, QgsFeature,
                       QgsGeometry, QgsRectangle, QgsField, QgsVectorFileWriter,
                       QgsCoordinateTransform, QgsCoordinateReferenceSystem, QgsPointXY,
                       QgsFillSymbol, QgsLayoutExporter, QgsProject, QgsMapLayerLegendUtils)

TOOL_VERSION = '1.0'
REPORT_NAMES = ('DamBreak_PAR_Report.xlsx', 'Dam_Report.xlsx')
REPORT_SUBDIRS = ('', 'reports', os.path.join('04_outputs', 'reports'), 'outputs', 'report')


def find_report(project_home):
    """Look for the dashboard report next to the QGIS project (common sub-folders)."""
    if not project_home:
        return ''
    for sub in REPORT_SUBDIRS:
        for nm in REPORT_NAMES:
            p = os.path.join(project_home, sub, nm)
            if os.path.exists(p):
                return p
    return ''


def _folder_param(name, desc):
    try:
        beh = Qgis.ProcessingFileParameterBehavior.Folder
    except AttributeError:
        beh = QgsProcessingParameterFile.Folder
    return QgsProcessingParameterFile(name, desc, behavior=beh, optional=True)


# ------------------------------------------------------------------ compatibility helpers
def _advanced(p):
    try:
        p.setFlags(p.flags() | Qgis.ProcessingParameterFlag.Advanced)
    except AttributeError:
        p.setFlags(p.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
    return p


def _num_type(kind):
    try:
        return getattr(Qgis.ProcessingNumberParameterType, kind)
    except AttributeError:
        return getattr(QgsProcessingParameterNumber, kind)


def _src_type(kind):
    try:
        return getattr(Qgis.ProcessingSourceType, kind)
    except AttributeError:
        return getattr(QgsProcessing, 'Type' + kind)


# ------------------------------------------------------------------ report reader (stdlib only)
def read_xlsx_sheet(path, sheet_name):
    ns = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
          'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
    with zipfile.ZipFile(path) as z:
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        rmap = {r.get('Id'): r.get('Target') for r in rels}
        target = None
        for s in wb.find('m:sheets', ns):
            if s.get('name') == sheet_name:
                target = rmap[s.get('{%s}id' % ns['r'])]
        if target is None:
            raise KeyError(sheet_name)
        target = target.lstrip('/')
        if not target.startswith('xl/'):
            target = 'xl/' + target
        shared = []
        if 'xl/sharedStrings.xml' in z.namelist():
            ss = ET.fromstring(z.read('xl/sharedStrings.xml'))
            for si in ss.findall('m:si', ns):
                shared.append(''.join(t.text or '' for t in si.iter('{%s}t' % ns['m'])))
        sh = ET.fromstring(z.read(target))
    rows = []
    for row in sh.iter('{%s}row' % ns['m']):
        vals = {}
        for c in row.findall('m:c', ns):
            ref = re.match(r'([A-Z]+)', c.get('r')).group(1)
            col = 0
            for ch in ref:
                col = col * 26 + ord(ch) - 64
            t = c.get('t')
            if t == 'inlineStr':
                v = ''.join(x.text or '' for x in c.iter('{%s}t' % ns['m']))
            else:
                ve = c.find('m:v', ns)
                v = ve.text if ve is not None else None
                if v is not None:
                    if t == 's':
                        v = shared[int(v)]
                    elif t not in ('str', 'b'):
                        try:
                            v = float(v)
                            v = int(v) if v.is_integer() else v
                        except ValueError:
                            pass
            vals[col] = v
        if vals:
            rows.append([vals.get(i) for i in range(1, max(vals) + 1)])
    return rows


def _num(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    m = re.search(r'-?\d+(\.\d+)?', str(v).replace(',', ''))
    val = float(m.group()) if m else None
    if val is not None and re.search(r'[SW]\b', str(v)):
        val = -val
    return val


def report_info(path):
    kv = {}
    for name in ('Project Information', 'Executive Summary'):
        try:
            for r in read_xlsx_sheet(path, name):
                if len(r) >= 2 and r[0] is not None and r[1] is not None:
                    kv.setdefault(str(r[0]).strip(), r[1])
        except KeyError:
            pass
    date_txt = None
    for key in ('Generated On', 'Report Date', 'Assessment Date'):
        v = kv.get(key)
        if not v:
            continue
        s = str(v).split(',')[0].strip()
        for fmt in ('%d %B %Y', '%d %b %Y', '%B %Y'):
            try:
                d = datetime.datetime.strptime(s, fmt)
                date_txt = d.strftime('%d %b %Y') if '%d' in fmt else d.strftime('%b %Y')
                break
            except ValueError:
                pass
        if date_txt:
            break
    par = kv.get('Total Population at Risk')
    return {'dam': str(kv.get('Dam Name', '') or '').strip(),
            'river': str(kv.get('River', '') or '').strip(),
            'basin': str(kv.get('River Basin', '') or '').strip(),
            'peak': str(kv.get('Peak Breach Hydrograph', '') or '').replace(',', '').strip(),
            'par': f'{int(_num(par)):,}' if par is not None else '',
            'date': date_txt or '',
            'lat': _num(kv.get('Dam Latitude', kv.get('Latitude'))),
            'lon': _num(kv.get('Dam Longitude', kv.get('Longitude')))}


# ------------------------------------------------------------------ layout text
HEADING_EXPR = " [% lpad(to_string(\"sheet_no\"), 2, '0') %]"
BASEMAP_PROVIDERS = ('wms', 'xyz', 'arcgismapserver', 'wcs', 'vectortile')


def set_line(text, key_regex, value):
    return re.sub(r'(?m)^(\s*' + key_regex + r'\s*:\s*).*$', lambda m: m.group(1) + value, text)


def update_layout_text(layout, v, heading, feedback):
    """Title, PIC, Map Information, Date and the sheet heading. Returns previous dam name."""
    old_dam = None
    n_changed = 0
    heading_done = False
    labels = [i for i in layout.items() if isinstance(i, QgsLayoutItemLabel)]
    for it in labels:
        t0 = t = it.text()
        if 'Break Analysis' in t:
            m = re.search(r'(?m)^\s*(.*?)\s+Break Analysis', t)
            if m:
                old_dam = m.group(1)
            t = re.sub(r'(?m)^(\s*).*Break Analysis.*$',
                       lambda m: f"{m.group(1)}{v['dam']} Break Analysis ({v['mode']})", t)
            if v['pic']:
                t = re.sub(r'PIC-[A-Za-z0-9\-]+', v['pic'], t)
        if 'sheet_no' in t and '[%' in t:          # heading line set by an earlier run
            t = re.sub(r'(?m)^[^\n]*sheet_no[^\n]*$', heading + HEADING_EXPR, t, count=1)
            heading_done = True
        if 'River Basin' in t or 'Population at Risk' in t:
            t = set_line(t, r'River Basin', v['basin'])
            t = set_line(t, r'River', v['river'])
            t = set_line(t, r'DB Hydrograph Peak', v['peak'])
            t = set_line(t, r'Population at Risk', v['par'])
        if re.search(r'(?m)^\s*Date\s*:', t):
            t = set_line(t, r'Date', v['date'])
        if v.get('scale_txt') and re.search(r'(?m)^\s*Scale\s*:', t):
            t = set_line(t, r'Scale', v['scale_txt'])
        if t != t0:
            it.setText(t)
            n_changed += 1
    if not heading_done:                           # first run on a template: "... Map 01" line
        for it in labels:
            t = it.text()
            m = re.search(r'(?m)^[^\n]*\bMap\s+\d{1,3}\s*$', t)
            if m and 'Break Analysis' not in m.group(0):
                it.setText(t[:m.start()] + heading + HEADING_EXPR + t[m.end():])
                heading_done = True
                n_changed += 1
                break
    if not heading_done:
        feedback.pushWarning('No heading label found (a label with a line like "Maximum Inundation Map 01"). '
                             'Add one to the layout to show the sheet heading.')
    feedback.pushInfo(f'Layout labels updated: {n_changed} (previous dam in title: {old_dam})')
    return old_dam


def update_legend(layout, theme, map_layers, title, old_dam, new_dam, rebuild, feedback):
    for lg in [i for i in layout.items() if isinstance(i, QgsLayoutItemLegend)]:
        try:
            if rebuild:
                lg.setAutoUpdateModel(False)
                root = lg.model().rootGroup()
                keep = {l.id() for l in map_layers if l.providerType() not in BASEMAP_PROVIDERS}
                for node in list(root.findLayers()):
                    if node.layerId() not in keep:
                        node.parent().removeChildNode(node)
                present = {n.layerId() for n in root.findLayers()}
                if theme.id() not in present:
                    root.insertLayer(0, theme)
                for l in map_layers:
                    if l.id() in keep and l.id() not in present and l.id() != theme.id():
                        root.addLayer(l)
                tnode = root.findLayer(theme.id())
                if title and tnode:
                    tnode.setCustomProperty('legend/title-label', title)
            # drop raster "Band 1 (Gray)" style header rows from the legend
            for node in lg.model().rootGroup().findLayers():
                items = lg.model().layerLegendNodes(node)
                keep = [i for i, n in enumerate(items)
                        if not re.match(r'^Band \d+', str(n.data(Qt.DisplayRole) or ''))]
                if items and len(keep) < len(items):
                    QgsMapLayerLegendUtils.setLegendNodeOrder(node, keep)
                    lg.model().refreshLayerLegend(node)
            if old_dam and old_dam != new_dam:
                for node in lg.model().rootGroup().findLayers():
                    lbl = node.customProperty('legend/title-label') or node.name()
                    if old_dam in lbl:
                        node.setCustomProperty('legend/title-label', lbl.replace(old_dam, new_dam))
            lg.updateLegend()
        except Exception as e:
            feedback.pushWarning(f'Legend update skipped: {e}')


# ------------------------------------------------------------------ sheet tracing
def trace_sheets(rlyr, dpt, W, H, cell, min_depth, margin, seed_r, storage, sheet1_current, cur,
                 prj, feedback):
    ds = gdal.Open(rlyr.source())
    if ds is None:
        raise QgsProcessingException(f'Cannot open raster {rlyr.source()}')
    gt = ds.GetGeoTransform()
    b = ds.GetRasterBand(1)
    f = max(1.0, cell / abs(gt[1]))
    bx, by = max(1, int(ds.RasterXSize / f)), max(1, int(ds.RasterYSize / f))
    arr = b.ReadAsArray(0, 0, ds.RasterXSize, ds.RasterYSize, bx, by).astype('float64')
    nd = b.GetNoDataValue()
    wet = np.isfinite(arr) & (arr > min_depth)
    if nd is not None:
        wet &= arr != nd
    csx = gt[1] * ds.RasterXSize / bx
    csy = gt[5] * ds.RasterYSize / by
    x0, y0 = gt[0], gt[3]
    ds = None
    rows, cols = wet.shape
    wi, wj = np.nonzero(wet)
    if len(wi) == 0:
        raise QgsProcessingException('No flooded cells found in the sheet-layout raster.')
    cx = x0 + (wj + 0.5) * csx
    cy = y0 + (wi + 0.5) * csy

    r2 = (cx - dpt.x()) ** 2 + (cy - dpt.y()) ** 2
    seeds = np.nonzero(r2 <= seed_r ** 2)[0]
    if len(seeds) == 0:
        seeds = [int(np.argmin(r2))]
        feedback.pushWarning(f'No flooded cell within {seed_r:.0f} m of the dam; nearest used '
                             f'({np.sqrt(r2[seeds[0]]):.0f} m away). Check the dam location.')
    trav = wet.copy()
    for _ in range(2):
        t = trav.copy()
        t[1:, :] |= trav[:-1, :]; t[:-1, :] |= trav[1:, :]
        t[:, 1:] |= trav[:, :-1]; t[:, :-1] |= trav[:, 1:]
        trav = t
    dist = np.full(wet.shape, np.inf)
    q = deque()
    for k in seeds:
        dist[wi[k], wj[k]] = 0
        q.append((wi[k], wj[k]))
    step = abs(csx)
    nbrs = [(-1, 0, 1), (1, 0, 1), (0, -1, 1), (0, 1, 1),
            (-1, -1, 1.414), (-1, 1, 1.414), (1, -1, 1.414), (1, 1, 1.414)]
    while q:
        i, j = q.popleft()
        d = dist[i, j]
        for di, dj, w in nbrs:
            a, c = i + di, j + dj
            if 0 <= a < rows and 0 <= c < cols and trav[a, c]:
                nd_ = d + w * step
                if nd_ < dist[a, c] - 1e-6:
                    dist[a, c] = nd_
                    q.append((a, c))
    D = dist[wi, wj]
    reach = np.isfinite(D)
    feedback.pushInfo(f'Flooded cells traced from dam: {reach.sum()} of {len(D)}; '
                      f'flow length {D[reach].max() / 1000:.1f} km')

    def inside(r, x, y):
        return (x >= r.xMinimum()) & (x <= r.xMaximum()) & (y >= r.yMinimum()) & (y <= r.yMaximum())

    def fit_window(mask, d0, ex=(), ey=()):
        ex, ey = np.asarray(ex, float), np.asarray(ey, float)
        hi = d0 + 1.5 * max(W, H)
        while hi >= d0:
            sel = mask & (D <= hi)
            xs, ys = np.concatenate([cx[sel], ex]), np.concatenate([cy[sel], ey])
            if len(xs) and xs.max() - xs.min() + 2 * margin <= W and ys.max() - ys.min() + 2 * margin <= H:
                mx, my = (xs.max() + xs.min()) / 2, (ys.max() + ys.min()) / 2
                return QgsRectangle(mx - W / 2, my - H / 2, mx + W / 2, my + H / 2)
            hi -= 0.02 * max(W, H)
        return None

    if sheet1_current:
        ext0 = cur
    else:
        ex, ey = [dpt.x()], [dpt.y()]
        if storage:
            se = QgsCoordinateTransform(storage.crs(), rlyr.crs(), prj).transformBoundingBox(storage.extent())
            if se.width() + 2 * margin <= W and se.height() + 2 * margin <= H:
                ex += [se.xMinimum(), se.xMaximum()]
                ey += [se.yMinimum(), se.yMaximum()]
            else:
                feedback.pushInfo('Reservoir larger than one sheet: Sheet 1 centred on dam + flood.')
        ext0 = fit_window(reach, 0.0, ex, ey) or QgsRectangle(
            dpt.x() - W / 4, dpt.y() - H / 2, dpt.x() + 3 * W / 4, dpt.y() + H / 2)

    sheets = [ext0]
    covered = inside(ext0, cx, cy)
    while len(sheets) < 150:
        if feedback.isCanceled():
            break
        left = reach & ~covered
        if left.sum() < 15:
            break
        d0 = D[left].min()
        rect = fit_window(left, d0)
        if rect is None:
            k0 = np.nonzero(left & (D == d0))[0][0]
            rect = QgsRectangle(cx[k0] - W / 2, cy[k0] - H / 2, cx[k0] + W / 2, cy[k0] + H / 2)
        if not (inside(rect, cx, cy) & ~covered).any():
            break
        covered |= inside(rect, cx, cy)
        sheets.append(rect)
    feedback.pushInfo(f'Sheets: {len(sheets)}; unmapped flooded cells: {int((reach & ~covered).sum())}')
    return sheets


def nice(x):
    """Round to 1, 2, 2.5 or 5 x 10^n."""
    if x <= 0:
        return x
    e = 10 ** np.floor(np.log10(x))
    for m in (1, 2, 2.5, 5, 10):
        if x <= m * e * 1.15:
            return float(m * e)
    return float(10 * e)


def rescale_map_items(layout, mapi, ratio, feedback):
    """Keep scale bar length and grid density similar after a scale change (ratio = new/old)."""
    for sb in [i for i in layout.items() if isinstance(i, QgsLayoutItemScaleBar)]:
        if sb.linkedMap() in (None, mapi):
            try:
                old = sb.unitsPerSegment()
                sb.setUnitsPerSegment(nice(old * ratio))
                sb.update()
                feedback.pushInfo(f'Scale bar segment: {old:g} -> {sb.unitsPerSegment():g} map units')
            except Exception as e:
                feedback.pushWarning(f'Scale bar not adjusted: {e}')
    try:
        grids = mapi.grids().asList()
    except Exception:
        grids = []
    for g in grids:
        try:
            ix, iy = g.intervalX(), g.intervalY()
            gcrs = g.crs() if g.crs().isValid() else mapi.crs()
            if gcrs.isGeographic():                               # degrees: snap to clean arc-seconds
                steps = [1, 2, 5, 10, 15, 20, 30, 45, 60, 90, 120, 150, 180, 300, 450, 600, 900, 1200,
                         1800, 3600, 7200]
                f = lambda x: min(steps, key=lambda st: abs(st - x * ratio * 3600)) / 3600.0
            else:
                f = lambda x: nice(x * ratio)
            g.setIntervalX(f(ix))
            g.setIntervalY(f(iy))
            feedback.pushInfo(f'Grid "{g.name()}" interval: {ix:g} -> {g.intervalX():g}')
        except Exception as e:
            feedback.pushWarning(f'Grid not adjusted: {e}')


def slug(s):
    return re.sub(r'\W+', '_', s).strip('_')


# ------------------------------------------------------------------ algorithm
class DamBreakMapSeriesShared(QgsProcessingAlgorithm):
    LAYOUT, MAP, THEME, HEADING, LEGEND_TITLE = 'LAYOUT', 'MAP', 'THEME', 'HEADING', 'LEGEND_TITLE'
    OTHER_LAYERS, UPDATE_LEGEND = 'OTHER_LAYERS', 'UPDATE_LEGEND'
    SHEET_RASTER, SHEETS_IN, STORAGE, SHEET1 = 'SHEET_RASTER', 'SHEETS_IN', 'STORAGE', 'SHEET1'
    DAM_NAME, PIC, MODE, REPORT = 'DAM_NAME', 'PIC', 'MODE', 'REPORT'
    RIVER, BASIN, PEAK, PAR, DATE, DAM_POINT = 'RIVER', 'BASIN', 'PEAK', 'PAR', 'DATE', 'DAM_POINT'
    EXPORT, DPI, OUT_DIR, PREFIX, SCALE = 'EXPORT', 'DPI', 'OUT_DIR', 'PREFIX', 'SCALE'
    MARGIN, CELL, MIN_DEPTH, SEED_RADIUS = 'MARGIN', 'CELL', 'MIN_DEPTH', 'SEED_RADIUS'
    SHEET1_OPTIONS = ['Automatic (dam + reservoir + first flood stretch)',
                      'Use current extent of the layout map']

    def tr(self, s):
        return QCoreApplication.translate('DamBreakMapSeriesShared', s)

    def createInstance(self):
        return DamBreakMapSeriesShared()

    def name(self):
        return 'dambreak_map_series_atlas'

    def displayName(self):
        return self.tr('Dam Break Map Series (Atlas + PNG)')

    def group(self):
        return self.tr('Dam Break Map Tools')

    def groupId(self):
        return 'dambreakmaptools'

    def flags(self):
        try:
            return super().flags() | Qgis.ProcessingAlgorithmFlag.NoThreading
        except AttributeError:
            return super().flags() | QgsProcessingAlgorithm.FlagNoThreading

    def shortHelpString(self):
        return self.tr(
            '<p>Creates a dam-break <b>map series</b> for any styled layer - maximum depth, velocity, '
            'hazard / vulnerability, arrival time ... - at the scale of the selected layout map '
            '(e.g. 1:50,000). Sheet 1 covers the dam; following sheets step downstream until the flood ends.</p>'
            '<p><b>Thematic layer</b>: style it first (symbology is used as is). '
            '<b>Map heading</b> becomes "&lt;heading&gt; 01, 02 ..." and <b>Legend title</b> renames the '
            'layer in the legend.</p>'
            '<p><b>Other layers</b>: dam, reservoir, basemap ... to show with the theme. If empty, the '
            'currently visible layers are used, but other local rasters are left out so only the chosen '
            'theme is drawn.</p>'
            '<p><b>Sheets</b>: traced along the flood from the dam using the sheet-layout raster '
            '(normally the max depth raster). To keep identical sheets for every theme, select the '
            '<i>sheet index from an earlier run</i> (&lt;Dam&gt;_EAP_sheets.gpkg). You can also edit '
            'that index by hand and reuse it.</p>'
            '<p><b>Dashboard report</b>: River, River Basin, DB peak, Population at Risk, Date and dam '
            'location are read from the report (.xlsx, sheet "Project Information" - see the report template '
            'in the pack); typed values override the report.</p>'
            '<p><b>Layout</b>: start from EAP_Map_Series_Layout_Template.qpt or keep the same label wording '
            'in your own layout.</p>'
            '<p><i>Developed by Rushikesh Jadhav. Version 1.0.</i></p>')

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterLayout(self.LAYOUT, self.tr('Print layout')))
        self.addParameter(QgsProcessingParameterLayoutItem(
            self.MAP, self.tr('Main map item in layout (its scale is used, e.g. 1:50,000)'),
            parentLayoutParameterName=self.LAYOUT, itemType=QgsLayoutItemRegistry.LayoutMap))
        self.addParameter(QgsProcessingParameterNumber(
            self.SCALE, self.tr('Map scale 1: (e.g. 25000, 50000, 100000; 0 = keep layout map scale)'),
            type=_num_type('Integer'), defaultValue=50000, minValue=0))
        self.addParameter(QgsProcessingParameterNumber(
            self.DPI, self.tr('Export resolution (dpi), e.g. 150 / 300 / 350 / 600'),
            type=_num_type('Integer'), defaultValue=350, minValue=72, maxValue=1200))
        self.addParameter(QgsProcessingParameterMapLayer(
            self.THEME, self.tr('Thematic layer to map (depth, velocity, hazard, vulnerability ... styled as needed)')))
        self.addParameter(QgsProcessingParameterString(
            self.HEADING, self.tr('Map heading (sheet number is added: "<heading> 01")'),
            defaultValue='Maximum Inundation Map'))
        self.addParameter(QgsProcessingParameterString(
            self.LEGEND_TITLE, self.tr('Legend title for the thematic layer, e.g. Maximum Velocity (m/s) '
                                       '(empty = keep current)'), optional=True))
        self.addParameter(QgsProcessingParameterMultipleLayers(
            self.OTHER_LAYERS, self.tr('Other layers on the maps: dam, reservoir, basemap ... '
                                       '(empty = visible layers)'),
            layerType=_src_type('MapLayer'), optional=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.UPDATE_LEGEND, self.tr('Update legend to the layers on the map'), defaultValue=True))

        self.addParameter(QgsProcessingParameterVectorLayer(
            self.SHEETS_IN, self.tr('Reuse sheet index from an earlier run (same sheets for every theme)'),
            [_src_type('VectorPolygon')], optional=True))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.SHEET_RASTER, self.tr('Sheet-layout raster: max depth / flood raster used to trace sheets '
                                       '(empty = thematic layer if raster)'), optional=True))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.STORAGE, self.tr('Dam storage / reservoir polygon (fitted on Sheet 1)'),
            [_src_type('VectorPolygon')], optional=True))
        self.addParameter(QgsProcessingParameterEnum(
            self.SHEET1, self.tr('Sheet 1 (dam sheet) when tracing'), options=self.SHEET1_OPTIONS,
            defaultValue=0))

        self.addParameter(QgsProcessingParameterString(
            self.DAM_NAME, self.tr('Dam name, e.g. Sample Dam (empty = from report)'), optional=True))
        self.addParameter(QgsProcessingParameterString(self.PIC, self.tr('Dam ID / PIC number, e.g. PIC-XXXXXXXXXX (replaces the "PIC-..." text in the title)'),
                                                       optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.MODE, self.tr('Failure mode'), defaultValue='Overtopping'))
        self.addParameter(QgsProcessingParameterFile(
            self.REPORT, self.tr('Dam report (.xlsx, see report template) (empty = search next to the QGIS project)'),
            extension='xlsx', optional=True))
        for key, label in [(self.RIVER, 'River (empty = from report)'),
                           (self.BASIN, 'River basin (empty = from report)'),
                           (self.PEAK, 'DB hydrograph peak, e.g. 12345.67 Cumecs (empty = from report)'),
                           (self.PAR, 'Population at risk (empty = from report)'),
                           (self.DATE, 'Map date, e.g. 12 Nov 2026 (empty = from report / today)')]:
            self.addParameter(QgsProcessingParameterString(key, self.tr(label), optional=True))
        self.addParameter(QgsProcessingParameterPoint(
            self.DAM_POINT, self.tr('Dam location (empty = lat/long from report)'), optional=True))

        self.addParameter(QgsProcessingParameterBoolean(self.EXPORT, self.tr('Export PNG'), defaultValue=True))
        self.addParameter(QgsProcessingParameterString(
            self.PREFIX, self.tr('File name prefix (empty = <Dam>_<Heading>_  ->  ..._01.png)'), optional=True))
        self.addParameter(_folder_param(
            self.OUT_DIR, self.tr('Output folder (empty = "map_series_output" next to the QGIS project)')))

        self.addParameter(_advanced(QgsProcessingParameterNumber(
            self.MARGIN, self.tr('Free margin around flood inside a sheet (m)'),
            type=_num_type('Double'), defaultValue=300.0, minValue=0.0)))
        self.addParameter(_advanced(QgsProcessingParameterNumber(
            self.CELL, self.tr('Analysis cell size for tracing (m)'),
            type=_num_type('Double'), defaultValue=60.0, minValue=5.0)))
        self.addParameter(_advanced(QgsProcessingParameterNumber(
            self.MIN_DEPTH, self.tr('Minimum raster value counted as flooded'),
            type=_num_type('Double'), defaultValue=0.0)))
        self.addParameter(_advanced(QgsProcessingParameterNumber(
            self.SEED_RADIUS, self.tr('Search radius around dam for flood start (m)'),
            type=_num_type('Double'), defaultValue=1500.0, minValue=50.0)))

        self.addOutput(QgsProcessingOutputNumber('SHEET_COUNT', self.tr('Number of sheets')))
        self.addOutput(QgsProcessingOutputString('SHEET_GPKG', self.tr('Sheet index GeoPackage')))
        self.addOutput(QgsProcessingOutputString('PNG_FOLDER', self.tr('PNG folder')))

    # --------------------------------------------------------------
    def processAlgorithm(self, parameters, context, feedback):
        prj = context.project() or QgsProject.instance()
        layout = self.parameterAsLayout(parameters, self.LAYOUT, context)
        if layout is None:
            raise QgsProcessingException('Select a print layout.')
        mapi = self.parameterAsLayoutItem(parameters, self.MAP, context, layout)
        if not isinstance(mapi, QgsLayoutItemMap):
            raise QgsProcessingException('Select the main map item of the layout.')
        theme = self.parameterAsLayer(parameters, self.THEME, context)
        if theme is None:
            raise QgsProcessingException('Select the thematic layer.')
        heading = (self.parameterAsString(parameters, self.HEADING, context) or '').strip() or 'Map'
        legend_title = (self.parameterAsString(parameters, self.LEGEND_TITLE, context) or '').strip()
        others = self.parameterAsLayerList(parameters, self.OTHER_LAYERS, context)
        sheets_in = self.parameterAsVectorLayer(parameters, self.SHEETS_IN, context)
        sheet_raster = self.parameterAsRasterLayer(parameters, self.SHEET_RASTER, context)
        storage = self.parameterAsVectorLayer(parameters, self.STORAGE, context)

        # ---- values: report, then dialog overrides
        rep_path = self.parameterAsFile(parameters, self.REPORT, context) or find_report(prj.homePath())
        rep = {}
        if rep_path and os.path.exists(rep_path):
            rep = report_info(rep_path)
            feedback.pushInfo(f'Report read: {rep_path}')
        elif rep_path:
            feedback.pushWarning(f'Report not found: {rep_path}')

        def pick(param, key):
            s = (self.parameterAsString(parameters, param, context) or '').strip()
            return s or rep.get(key, '') or ''

        v = {'dam': pick(self.DAM_NAME, 'dam'), 'river': pick(self.RIVER, 'river'),
             'basin': pick(self.BASIN, 'basin'), 'peak': pick(self.PEAK, 'peak'),
             'par': pick(self.PAR, 'par'), 'date': pick(self.DATE, 'date'),
             'pic': (self.parameterAsString(parameters, self.PIC, context) or '').strip(),
             'mode': (self.parameterAsString(parameters, self.MODE, context) or 'Overtopping').strip()}
        if not v['dam']:
            raise QgsProcessingException('Dam name missing: type it or provide the dashboard report.')
        if v['river'] and not v['river'].lower().endswith('river'):
            v['river'] += ' River'
        if v['par'] and re.fullmatch(r'\d+', v['par']):
            v['par'] = f"{int(v['par']):,}"
        if v['peak'] and re.fullmatch(r'[\d.,]+', v['peak']):
            v['peak'] = v['peak'].replace(',', '') + ' Cumecs'
        if not v['date']:
            v['date'] = datetime.date.today().strftime('%d %b %Y')
        for k in ('river', 'basin', 'peak', 'par', 'pic'):
            if not v[k]:
                feedback.pushWarning(f'"{k}" is empty - that text in the layout will be blank/unchanged.')
        feedback.pushInfo('Values used: ' + ', '.join(f'{k}={v[k]}' for k in v))
        dam_short = slug(re.sub(r'(?i)\s*dam$', '', v['dam']))

        # ---- layers on the map: theme + others (layer tree order)
        if others:
            chosen = [l for l in others if l.id() != theme.id()]
        else:
            chosen = [l for l in prj.layerTreeRoot().checkedLayers()
                      if l.id() != theme.id()
                      and not (isinstance(l, QgsRasterLayer) and l.providerType() == 'gdal')
                      and not l.name().endswith('_Map_Sheets')]
        wanted = {l.id() for l in chosen} | {theme.id()}
        order = [l for l in prj.layerTreeRoot().layerOrder() if l.id() in wanted]
        order += [l for l in [theme] + chosen if l not in order]
        if layout.atlas().enabled():
            mapi.setAtlasDriven(False)
        mapi.setFollowVisibilityPreset(False)
        mapi.setLayers(order)
        mapi.setKeepLayerSet(True)
        feedback.pushInfo('Layers on maps (top to bottom): ' + ', '.join(l.name() for l in order))

        scale = self.parameterAsInt(parameters, self.SCALE, context)
        old_scale = mapi.scale()
        if scale > 0 and abs(scale - old_scale) > 0.5:
            mapi.setScale(scale)
            rescale_map_items(layout, mapi, scale / old_scale, feedback)
            feedback.pushInfo(f'Map scale changed 1:{old_scale:,.0f} -> 1:{scale:,}')
        v['scale_txt'] = f'1:{mapi.scale():,.0f}'

        old_dam = update_layout_text(layout, v, heading, feedback)
        update_legend(layout, theme, order, legend_title, old_dam, v['dam'],
                      self.parameterAsBool(parameters, self.UPDATE_LEGEND, context), feedback)

        cur = QgsRectangle(mapi.extent())
        W, H = cur.width(), cur.height()
        feedback.pushInfo(f'Sheet ground size {W:.0f} x {H:.0f} m at 1:{mapi.scale():.0f}')
        feedback.setProgress(10)

        out_root = (self.parameterAsString(parameters, self.OUT_DIR, context) or '').strip()
        if not out_root:
            if not prj.homePath():
                raise QgsProcessingException('Save the QGIS project first, or choose an output folder.')
            out_root = os.path.join(prj.homePath(), 'map_series_output')
        feedback.pushInfo(f'Output folder: {out_root}')
        os.makedirs(out_root, exist_ok=True)

        # ---- sheets: reuse or trace
        if sheets_in:
            if sheets_in.fields().indexOf('sheet_no') < 0:
                raise QgsProcessingException('The reused sheet index needs an integer field "sheet_no".')
            lyr = sheets_in
            gpkg = lyr.source().split('|')[0]
            n_sheets = lyr.featureCount()
            feedback.pushInfo(f'Reusing {n_sheets} sheets from {lyr.name()}')
            f0 = next(lyr.getFeatures(), None)
            if f0 is not None:
                bb = QgsCoordinateTransform(lyr.crs(), mapi.crs(), prj).transformBoundingBox(
                    f0.geometry().boundingBox())
                if abs(bb.width() - W) > 0.03 * W or abs(bb.height() - H) > 0.03 * H:
                    raise QgsProcessingException(
                        f'The reused sheet index was made for another scale/frame size '
                        f'(sheet {bb.width():.0f} x {bb.height():.0f} m, map now needs {W:.0f} x {H:.0f} m '
                        f'at {v["scale_txt"]}). Clear "Reuse sheet index" to trace new sheets at this scale.')
            layout.atlas().setCoverageLayer(None)
        else:
            rlyr = sheet_raster or (theme if isinstance(theme, QgsRasterLayer) else None)
            if rlyr is None:
                raise QgsProcessingException('Choose a sheet-layout raster (max depth) or reuse a sheet index '
                                             '- the thematic layer is not a raster.')
            if rlyr.crs().isGeographic():
                raise QgsProcessingException('Sheet-layout raster must be in a projected CRS (metres).')
            if prj.crs() != rlyr.crs():
                feedback.pushWarning('Project CRS differs from the sheet-layout raster CRS; keep them the same '
                                     'for exact sheet fitting.')
            rcrs = rlyr.crs()
            if parameters.get(self.DAM_POINT):
                dpt = self.parameterAsPoint(parameters, self.DAM_POINT, context, rcrs)
            elif rep.get('lat') is not None and rep.get('lon') is not None:
                dpt = QgsCoordinateTransform(QgsCoordinateReferenceSystem('EPSG:4326'), rcrs, prj).transform(
                    QgsPointXY(rep['lon'], rep['lat']))
            else:
                raise QgsProcessingException('Dam location missing: pick it on the map or provide the report.')
            sheets = trace_sheets(
                rlyr, dpt, W, H,
                self.parameterAsDouble(parameters, self.CELL, context),
                self.parameterAsDouble(parameters, self.MIN_DEPTH, context),
                self.parameterAsDouble(parameters, self.MARGIN, context),
                self.parameterAsDouble(parameters, self.SEED_RADIUS, context),
                storage, self.parameterAsEnum(parameters, self.SHEET1, context) == 1, cur, prj, feedback)
            if feedback.isCanceled():
                return {}
            n_sheets = len(sheets)

            lname = f'{dam_short}_Map_Sheets'
            gpkg = os.path.join(out_root, f'{dam_short}_EAP_sheets.gpkg')
            mem = QgsVectorLayer(f'Polygon?crs={rcrs.authid()}', lname, 'memory')
            pr = mem.dataProvider()
            pr.addAttributes([QgsField('sheet_no', QVariant.Int), QgsField('sheet_lbl', QVariant.String),
                              QgsField('xmin', QVariant.Double), QgsField('ymin', QVariant.Double),
                              QgsField('xmax', QVariant.Double), QgsField('ymax', QVariant.Double)])
            mem.updateFields()
            feats = []
            for n, r in enumerate(sheets, 1):
                ft = QgsFeature(mem.fields())
                ft.setGeometry(QgsGeometry.fromRect(r))
                ft.setAttributes([n, f'Map {n:02d}', r.xMinimum(), r.yMinimum(), r.xMaximum(), r.yMaximum()])
                feats.append(ft)
            pr.addFeatures(feats)
            layout.atlas().setCoverageLayer(None)
            norm = os.path.normcase(os.path.abspath(gpkg))
            for l in list(prj.mapLayers().values()):
                if l.name() == lname or os.path.normcase(os.path.abspath(l.source().split('|')[0])) == norm:
                    prj.removeMapLayer(l.id())
            opts = QgsVectorFileWriter.SaveVectorOptions()
            opts.driverName = 'GPKG'
            opts.layerName = lname
            res = QgsVectorFileWriter.writeAsVectorFormatV3(mem, gpkg, prj.transformContext(), opts)
            if res[0] != QgsVectorFileWriter.NoError:
                raise QgsProcessingException(f'Could not write {gpkg}: {res}')
            lyr = QgsVectorLayer(f'{gpkg}|layername={lname}', lname, 'ogr')
            lyr.renderer().setSymbol(QgsFillSymbol.createSimple(
                {'color': '0,0,0,0', 'outline_color': '255,0,0', 'outline_width': '0.6'}))
            prj.addMapLayer(lyr)
        node = prj.layerTreeRoot().findLayer(lyr.id())
        if node:
            node.setItemVisibilityChecked(False)
        feedback.setProgress(40)

        # ---- atlas
        prefix = (self.parameterAsString(parameters, self.PREFIX, context) or '').strip() \
            or f'{dam_short}_{slug(heading)}_'
        atlas = layout.atlas()
        atlas.setCoverageLayer(lyr)
        atlas.setEnabled(True)
        atlas.setHideCoverage(True)
        atlas.setSortFeatures(True)
        atlas.setSortAscending(True)
        atlas.setSortExpression('"sheet_no"')
        atlas.setPageNameExpression("'Map ' || lpad(to_string(\"sheet_no\"), 2, '0')")
        atlas.setFilenameExpression(f"'{prefix}' || lpad(to_string(\"sheet_no\"), 2, '0')")
        mapi.setAtlasDriven(True)
        mapi.setAtlasScalingMode(QgsLayoutItemMap.Fixed)
        atlas.updateFeatures()
        layout.refresh()
        try:
            from qgis.utils import iface
            for dsg in iface.openLayoutDesigners():
                if dsg.layout() == layout:
                    dsg.close()
                    iface.openLayoutDesigner(layout)
        except Exception:
            pass
        feedback.setProgress(45)

        # ---- export
        png_dir = ''
        if self.parameterAsBool(parameters, self.EXPORT, context):
            png_dir = os.path.join(out_root, prefix.rstrip('_') + '_PNG')
            os.makedirs(png_dir, exist_ok=True)
            s = QgsLayoutExporter.ImageExportSettings()
            s.dpi = self.parameterAsInt(parameters, self.DPI, context)
            feedback.pushInfo(f'Exporting {atlas.count()} sheets at {s.dpi} dpi to {png_dir} ...')
            r = QgsLayoutExporter.exportToImage(atlas, os.path.join(png_dir, 'sheet'), 'png', s)
            if r[0] != QgsLayoutExporter.Success:
                raise QgsProcessingException(f'PNG export failed: {r}')
            feedback.pushInfo(f'PNG export OK: {prefix}01.png ... {prefix}{atlas.count():02d}.png')
        feedback.setProgress(100)
        feedback.pushInfo('Done. Save the project to keep the Atlas setup.')
        return {'SHEET_COUNT': n_sheets, 'SHEET_GPKG': gpkg, 'PNG_FOLDER': png_dir}
