DAM BREAK MAP SERIES - QGIS Processing tool  (version 1.0)
==========================================================
Makes numbered downstream map series (e.g. 1:50,000) of any styled dam-break result layer
(maximum depth, velocity, hazard, vulnerability, arrival time ...) and exports them as PNG.

FILES
  dambreak_map_series.py               the Processing tool
  EAP_Map_Series_Layout_Template.qpt   A4 print layout to start from
  Dam_Report_TEMPLATE.xlsx             dam details written on the maps (fill yellow cells)
  User_Guide.pdf                       full guide

QUICK START
  1. QGIS > Processing Toolbox > Python icon > "Add Script to Toolbox..." > dambreak_map_series.py
  2. Project > Layout Manager > Create from template > EAP_Map_Series_Layout_Template.qpt
     (edit "Map Prepared by" etc. once; keep the label wording - see the guide)
  3. Style your result layers. Fill the report template, save as Dam_Report.xlsx next to the project.
  4. Run: Scripts > Dam Break Map Tools > Dam Break Map Series (Atlas + PNG)
       - first theme: choose the max depth raster as "Sheet-layout raster"
       - next themes: select <Dam>_EAP_sheets.gpkg under "Reuse sheet index" (same sheets for all)

Requires QGIS 3.28+ (tested 3.44 LTR) and data in a projected CRS (metres).
Developed by Rushikesh Jadhav. Free to use and adapt; please keep the credit.
